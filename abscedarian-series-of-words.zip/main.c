/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char s1[100], s2[100];
    char out[100];
    printf("enter the string 1:");
    scanf("%s",s1);
     printf("enter the string 2:");
    scanf("%s",s2);
    for(int i=0;i<strlen(s1);i++){
        snprintf(out, sizeof(out),"%c%s",s1[i],s2);
        printf("%s ",out);
    }
    printf("\n");
    return 0;
    
}    
